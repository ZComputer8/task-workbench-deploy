# 任务工作台 · 一键部署

把「任务计划分发记录工作台」部署到你自己的 WorkBuddy 资料库，**不含任何账号与任务数据**，独立使用。

## 快速开始（给部署者）

1. **安装 skill**：把本仓库整个文件夹放到你的 `~/.workbuddy/skills/` 目录下（文件夹名随意，如 `task-workbench-deploy`）。
2. **一句话部署**：在 WorkBuddy 对话里说：

> **部署任务工作台**

AI 会自动完成：建两张数据表 → 替换页面里的库 ID → 创建 web 页面并关联两张表 → 发布 → 返回访问链接 `https://workbuddy.link/p/xxxxxx`。

3. **权限**：
   - 自己使用：无需任何操作；
   - 给他人使用：在资料库界面把两张数据表设为「链接公开可编辑」或添加协作者（页面公开 ≠ 数据库公开）。

## 手动方式（不装 skill 也可以）

把空包 `assets/task-workbench-empty.zip` 解压，按包内 `README.md` 的"快速部署"指令发给 WorkBuddy，或按手动步骤操作。

## 仓库结构

```
├── SKILL.md                          # skill 定义（AI 读取后自动执行部署）
├── assets/task-workbench-empty.zip   # 空网站包（不含任何数据）
├── scripts/prepare_deploy.py         # 替换库 ID 脚本
├── references/deploy-guide.md        # 部署流程详解（供 AI 参考）
└── DEPLOY.md                         # 本文件
```

## 安全说明

- 空包与 skill **不含任何真实数据库 ID、账号、密码、任务数据**；
- 数据只产生在部署者自己的两张表里，互不串扰；
- 发布前请自行检查链接不要外传，权限按需设置。
