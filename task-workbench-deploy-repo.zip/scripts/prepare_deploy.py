#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
任务工作台 · 一键部署准备脚本
================================
从本 skill 内置的空包 zip 生成「替换好 database_id 的可发布 index.html」，
并输出建表 / 发布的后续命令指引。

用法:
  python3 prepare_deploy.py --task-db-id <任务表ID> --account-db-id <账户表ID> [--out-dir <输出目录>]

说明:
  - 若尚未建表，可省略两个 ID，脚本会先打印"建表命令"（用 skill-library 的 create_database.py）。
  - 建表后再带 ID 运行本脚本，生成可发布的 index.html。
"""
import argparse
import json
import os
import re
import shutil
import sys
import zipfile

SKILL_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ZIP_PATH = os.path.join(SKILL_ROOT, "assets", "task-workbench-empty.zip")
PLACEHOLDER_TASK = "__TASK_DB_ID__"
PLACEHOLDER_ACCOUNT = "__ACCOUNT_DB_ID__"


def find_schema_by(needle):
    """在空包 schema 目录里找包含指定字段名的 schema 文件。"""
    return None


def cmd_create_database(schema_path):
    return (
        'echo "$TOKEN" | python3 "$DB/create_database.py" --token-stdin '
        '--schema \'%(json)s\'' % {"json": json.dumps(json.load(open(schema_path, encoding="utf-8")), ensure_ascii=False)}
    )


def main():
    ap = argparse.ArgumentParser(description="任务工作台空包部署准备")
    ap.add_argument("--task-db-id", default="", help="任务表 database_id")
    ap.add_argument("--account-db-id", default="", help="账户表 database_id")
    ap.add_argument("--out-dir", default=".", help="输出目录（默认当前目录）")
    args = ap.parse_args()

    if not os.path.exists(ZIP_PATH):
        print("[错误] 未找到内置空包: %s" % ZIP_PATH)
        sys.exit(1)

    # 解压空包到临时目录
    tmp = os.path.join(args.out_dir, ".twb_stage")
    if os.path.exists(tmp):
        shutil.rmtree(tmp)
    os.makedirs(tmp)
    with zipfile.ZipFile(ZIP_PATH) as z:
        z.extractall(tmp)

    schema_dir = os.path.join(tmp, "schema")
    account_schema = os.path.join(schema_dir, "account-db.schema.json")
    task_schema = os.path.join(schema_dir, "task-db.schema.json")

    if not (args.task_db_id and args.account_db_id):
        print("=== 第 1 步：先建两张空数据表（如已建好可直接带 ID 重跑本脚本） ===")
        print("\n账户表（工作台-账户表）:")
        print(cmd_create_database(account_schema))
        print("\n任务表（任务计划分发记录表）:")
        print(cmd_create_database(task_schema))
        print("\n建好后把两张表的 database_id 传入本脚本再次运行即可生成可发布页面。")
        sys.exit(0)

    # 校验 ID 格式（22 位 base62 风格）
    for name, val in (("任务表", args.task_db_id), ("账户表", args.account_db_id)):
        if not re.fullmatch(r"[A-Za-z0-9]{20,24}", val):
            print("[警告] %s database_id 格式异常（期望 20~24 位字母数字）: %s" % (name, val))
            sys.exit(1)

    # 生成替换好的 index.html
    src_html = os.path.join(tmp, "index.html")
    html = open(src_html, encoding="utf-8").read()
    if PLACEHOLDER_TASK not in html or PLACEHOLDER_ACCOUNT not in html:
        print("[错误] 空包 index.html 中未找到占位符，请确认空包版本正确。")
        sys.exit(1)
    html = html.replace(PLACEHOLDER_TASK, args.task_db_id)
    html = html.replace(PLACEHOLDER_ACCOUNT, args.account_db_id)

    out_html = os.path.join(args.out_dir, "index.html")
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(html)

    # 校验
    left_task = html.count(PLACEHOLDER_TASK)
    left_account = html.count(PLACEHOLDER_ACCOUNT)
    if left_task or left_account:
        print("[错误] 仍有占位符残留: __TASK_DB_ID__=%d __ACCOUNT_DB_ID__=%d" % (left_task, left_account))
        sys.exit(1)

    # 顺带把 README 也复制到输出目录
    shutil.copy(os.path.join(tmp, "README.md"), os.path.join(args.out_dir, "README.md"))

    print("=== 部署产物已生成 ✅ ===")
    print("  index.html : %s" % os.path.abspath(out_html))
    print("  README.md  : %s" % os.path.abspath(os.path.join(args.out_dir, "README.md")))
    print("  schema/    : 两张表的建表 JSON 见空包内 schema 目录")
    print()
    print("=== 第 2 步：在资料库新建 web 页面并发布 ===")
    print("1. 在资料库空间新建一个「web 页面 / 网页」节点。")
    print("2. 把上面生成的 index.html 内容整体粘贴/上传进该页面。")
    print("3. 发布页面，得到公开链接 https://workbuddy.link/p/xxxxxx。")
    print("4. 打开链接，首个注册的使用者即主使用者（管理员），即可正常使用。")

    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
