---
name: task-workbench-deploy
description: |
  一键部署「任务工作台」独立网站（组织/账户 + 独立密码登录 + 任务四视图）。
  当用户想把任务管理功能部署到自己的 WorkBuddy 资料库、需要一份不含任何数据的空网站包，
  或说“部署任务工作台/任务管理系统/给我的团队搭一个任务系统”时使用。
  本 skill 内置空包 zip 与部署脚本，自动完成建表命令、database_id 替换、页面发布指引，
  并保证空包不含任何真实库 ID、账号、密码、任务数据。
---

# Task Workbench Deploy · 任务工作台一键部署

## Overview

把「任务计划分发记录工作台」部署到任意 WorkBuddy 资料库空间：**不含任何账号与任务数据**的独立网站，
首注册使用者即主使用者（管理员），每人独立密码登录，含任务四视图（列表/看板/日历/时间线）、
组织与权限、使用者管理、逾期与完成时效、模板、全年计划等完整功能。

本 skill 自带空包，不依赖外部链接；部署者可拿空包独立搭建，不会与当前项目数据串扰。

## 内置资源

- `assets/task-workbench-empty.zip` — 空网站包
  - `index.html`：页面源码，库 ID 为占位符 `__TASK_DB_ID__` / `__ACCOUNT_DB_ID__`
  - `README.md`：给部署者看的部署指南
  - `schema/account-db.schema.json`：账户表建表结构（8 字段）
  - `schema/task-db.schema.json`：任务表建表结构（17 字段）
- `scripts/prepare_deploy.py` — 部署准备脚本（建表命令 / 替换 ID / 生成可发布 index.html）
- `references/deploy-guide.md` — 给 AI 执行者的完整操作序列与易错点

## 部署流程（全自动，AI 执行；部署者只需一句话）

> 部署者指令示例：**"部署任务工作台"**
> AI 按下面 5 步自动完成，最终直接返回可访问链接。token 通过 `connect_open_platform(skill_id=library)` 获取。

### Step 1 · 建两张空数据表

用资料库 skill 的 `create_database.py` 按空包 schema 建表（schema 在解压后的空包里）：

```bash
DB="<library>/database"
echo "$TOKEN" | python3 "$DB/create_database.py" --token-stdin --schema "$(cat schema/account-db.schema.json)"  # → 记下账户表 database_id
echo "$TOKEN" | python3 "$DB/create_database.py" --token-stdin --schema "$(cat schema/task-db.schema.json)"    # → 记下任务表 database_id
```

### Step 2 · 生成替换好 ID 的可发布页面

```bash
python3 "<skill_dir>/scripts/prepare_deploy.py" \
  --task-db-id <任务表ID> --account-db-id <账户表ID> --out-dir <输出目录>
```

脚本自动解压内置空包 → 替换占位符 → 校验无残留 → 输出 `index.html` + `README.md`。

### Step 3 · 导入创建 web 页面并关联两张表（关键：不再需要前端手动建页面）

用资料库 skill 的 `import_html.py`（参考 clone-flow 分支 B），导入 HTML 即创建页面节点，并写入两张表的关联：

```bash
SKILL="<library>"
DB_JSON='[{"id":"<任务表ID>"},{"id":"<账户表ID>"}]'
printf '%s' "$TOKEN" | python3 "$SKILL/page/import_html.py" --token-stdin \
  "<输出目录>/index.html" --file-name "任务计划分发记录工作台.html" --databases "$DB_JSON"
# → KS_IMPORT_OK {"node_block_id":"<页面ID>", ...}
```

### Step 4 · 发布页面

```bash
echo "$TOKEN" | python3 "$SKILL/page/publish_page.py" --token-stdin --node-id <页面ID>
# → 返回 publishUrl：https://workbuddy.link/p/xxxxxx
```

### Step 5 · 权限提示（唯一保留的手动项）

- 部署者**自己使用**：无需任何权限操作。
- **要给他人使用**：在资料库界面把两张数据表设为「链接公开可编辑」或添加协作者（页面公开 ≠ 数据库公开）。

## 质检要求（必须执行）

每次部署前先对**交付给部署者的空包**做敏感信息扫描，确认零泄露：

- 真实数据库 ID、nodeId、空间 ID、组织信息、账号、密码、token、个人发布链接 **不得出现**。
- 空包 `index.html` 必须只含 `__TASK_DB_ID__` / `__ACCOUNT_DB_ID__` 占位符。

扫描命令参考（在空包目录执行）：

```bash
grep -rn "真实库ID\|账号\|密码\|token前缀\|workbuddy.link/p/实际链接" <空包目录>
```

## 易错点

- 占位符替换不干净 → 页面空白：务必 `grep "__"` 复查。
- 两张表缺一不可：账户表缺 → 无法注册；任务表缺 → 页面空白。
- `import_html` 的 `--databases` 参数顺序/内容必须与两张新表一致，否则页面读不到数据。
- 发布用 `publish_page`；若只要草稿态则不发布（克隆流程默认不发布）。
- 建表 schema 的 select 字段用 `config:{"select":{...}}`（create_database 的字段格式要求）。
