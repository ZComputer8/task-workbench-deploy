# 任务工作台 · 部署指南（供 Skill 执行者参考）

本文档给 AI 执行者提供"一键部署任务工作台"的完整操作序列。
空包与脚本都随本 skill 内置，不依赖任何外部链接。
每次部署都是全新创建（新表 + 新页面 + 新链接），重复部署也完全独立、互不覆盖。

## 内置资源位置

- 空包 zip：`assets/task-workbench-empty.zip`
  - 内含 `index.html`（库 ID 为占位符 `__TASK_DB_ID__` / `__ACCOUNT_DB_ID__`）、`README.md`、`schema/account-db.schema.json`、`schema/task-db.schema.json`
- 部署脚本：`scripts/prepare_deploy.py`

## 部署流程（全自动，6 步）

### 第 1 步：建两张空数据表

用资料库 skill 的 `create_database.py` 建表（schema 文件在空包内）：

```bash
DB="<skill-library>/database"
echo "$TOKEN" | python3 "$DB/create_database.py" --token-stdin --schema "$(cat schema/account-db.schema.json)"
echo "$TOKEN" | python3 "$DB/create_database.py" --token-stdin --schema "$(cat schema/task-db.schema.json)"
```

- token 通过 `connect_open_platform(skill_id=library)` 获取。
- 从返回中记下两张表的 database_id（形如 22 位字母数字）。

### 第 2 步：生成替换好 ID 的 index.html

```bash
python3 scripts/prepare_deploy.py \
  --task-db-id <任务表ID> \
  --account-db-id <账户表ID> \
  --out-dir <输出目录>
```

脚本会：
- 解压内置空包 → 全局替换两个占位符 → 输出 `index.html` + `README.md` 到输出目录；
- 校验无占位符残留、ID 格式正确。

### 第 3 步：导入创建 web 页面并关联两张表

用资料库 skill 的 `import_html.py`（参考 clone-flow 分支 B），导入 HTML 即创建页面节点，无需前端手动建页面：

```bash
SKILL="<skill-library>"
DB_JSON='[{"id":"<任务表ID>"},{"id":"<账户表ID>"}]'
FNAME="任务计划分发记录工作台-$(date +%Y%m%d-%H%M).html"  # 带日期+时分，几乎不可能重名
printf '%s' "$TOKEN" | python3 "$SKILL/page/import_html.py" --token-stdin \
  "<输出目录>/index.html" --file-name "$FNAME" --databases "$DB_JSON"
# → KS_IMPORT_OK {"node_block_id":"<页面ID>", "url":"..."}
```

- `--file-name` 用「任务计划分发记录工作台-YYYYMMDD-HHMM.html」：基础名 + 日期+时分，重复部署也不会同名；
- `--databases` 传入两张新表 ID，导入时自动写入页面与表的关联；
- 产物为草稿态页面（未发布）。

### 第 4 步：发布页面

```bash
echo "$TOKEN" | python3 "$SKILL/page/publish_page.py" --token-stdin --node-id <页面ID>
# → 返回 publishUrl：https://workbuddy.link/p/xxxxxx
```

### 第 5 步：权限提示（唯一手动项）

- 部署者自己使用：无需操作。
- 要给他人使用：资料库界面把两张表设为「链接公开可编辑」或加协作者（页面公开 ≠ 数据库公开）。

### 第 6 步：部署完成，确认后移除本 skill（必须执行）

1. 用 `present_files` 打开发布链接，校验链接可打开、可注册登录、数据正常。
2. 提示用户：**已部署成功，请测试；测试没问题请回复「确认」，我将移除临时安装的 skill。**
3. 用户回复「确认」后，删除本机 skills 目录下的 `task-workbench-deploy` 文件夹（移除本 skill）。
4. 提示：网站与数据独立保留在资料库，不受影响；想再部署时把同一句话再发一次即可。

## 易错点

- **占位符必须替换干净**：残留 `__` 会导致页面读不到库而空白。
- **两张表缺一不可**：账户表缺 → 无法注册登录；任务表缺 → 页面空白。
- **task-db 的 select 字段选项**：任务表 schema 里已含「优先级」「状态」选项；若部署者手动建表漏配，页面有 `DEFAULT_OPTIONS` 兜底，不影响主流程。
- **`--databases` 顺序/内容**必须与两张新表一致，否则页面读不到数据。
- **权限分离**：页面公开 ≠ 数据库公开；他人无法使用多为表权限未开放。

## 质检要求（防信息泄露）

部署者拿到的是**空包**：不含任何真实库 ID、账号、密码、任务数据、组织信息。
发布后验证时：
- 首注册者应为「主使用者（管理员）」；
- 新用户注册同一组织 → 不明账户（面板空）→ 主使用者授权后才可使用。
