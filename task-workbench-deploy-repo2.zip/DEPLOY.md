# 任务工作台 · 一键部署（第二套独立版）

把「任务计划分发记录工作台」部署到你自己的 WorkBuddy 资料库，**不含任何账号与任务数据**，独立使用。

> **本套为第二套（skill 名 `task-workbench-deploy2`，部署包 `task-workbench-deploy-repo2.zip`）**。
> 与第一套 `task-workbench-deploy` 完全独立共存：skill 名、页面文件名、发布链接互不冲突，
> 适合学习者先测第一套、再测本套。

## 快速开始（给部署者）

1. **安装 skill**：把本仓库整个文件夹放到你的 `~/.workbuddy/skills/` 目录下（文件夹名建议 `task-workbench-deploy2`）。
2. **一句话部署**：在 WorkBuddy 对话里发：

> **帮我一键部署任务工作台（第二套）：从 https://github.com/ZComputer8/task-workbench-deploy 下载源码包 task-workbench-deploy-repo2.zip，自动安装并部署，完成后打开链接。GitHub 不可用时用 https://gitee.com/ZComputer/task-workbench-deploy。**

AI 会自动完成：下载安装 skill → 建两张数据表 → 替换页面里的库 ID → 创建 web 页面并关联两张表 → 发布 → 打开发布链接 `https://workbuddy.link/p/xxxxxx`。

3. **用完移除**：部署成功、校验通过后，AI 会提醒你测试；回复「确认」后 WorkBuddy 自动移除临时安装的 skill。网站与数据独立保留在资料库，不受影响。

4. **权限**：
   - 自己使用：无需任何操作；
   - 给他人使用：在资料库界面把两张数据表设为「链接公开可编辑」或添加协作者（页面公开 ≠ 数据库公开）。

## 防冲突说明（学习者连续测试第一套/本套时）

| 维度 | 第一套 | 本套（第二套） |
|------|--------|----------------|
| 部署包 | `task-workbench-deploy-repo.zip` | `task-workbench-deploy-repo2.zip` |
| skill 名 | `task-workbench-deploy` | `task-workbench-deploy2` |
| 页面文件名 | 任务计划分发记录工作台.html | 任务计划分发记录工作台2.html |
| 数据表 | 每次部署新建 | 每次部署新建（独立） |

两套互不覆盖；本套部署完成后按确认移除 skill，避免残留。

## 手动方式（不装 skill 也可以）

把空包 `assets/task-workbench-empty.zip` 解压，按包内 `README.md` 的"快速部署"指令发给 WorkBuddy，或按手动步骤操作。

## 仓库结构

```
├── SKILL.md                          # skill 定义（AI 读取后自动执行部署）
├── assets/task-workbench-empty.zip   # 空网站包（不含任何数据）
├── scripts/prepare_deploy.py         # 替换库 ID 脚本
├── references/deploy-guide.md        # 部署流程详解（供 AI 参考）
└── DEPLOY.md                         # 本文件
```

## 安全说明

- 空包与 skill **不含任何真实数据库 ID、账号、密码、任务数据**；
- 数据只产生在部署者自己的两张表里，互不串扰；
- 发布前请自行检查链接不要外传，权限按需设置。
