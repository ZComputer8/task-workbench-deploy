# 任务工作台 · 一键部署

把「任务计划分发记录工作台」部署到你自己的 WorkBuddy 资料库，**不含任何账号与任务数据**，独立使用。
每次部署都是全新创建（新表 + 新页面 + 新链接），重复部署也完全独立、互不覆盖。

## 快速开始（给部署者）

**二选一**：手动安装 skill（方式 A），或直接发触发句让 AI 自动下载安装（方式 B）。

- **方式 A（手动）**：把本仓库整个文件夹放到你的 `~/.workbuddy/skills/` 目录下（文件夹名建议 `task-workbench-deploy`）。
- **方式 B（自动）**：什么都不用装，直接把下面的触发句发给 WorkBuddy，AI 会从 GitHub（失败自动切 Gitee）自动下载源码包并安装 skill。

**一句话部署**：在 WorkBuddy 对话里发：

> **帮我一键部署任务工作台：从 https://github.com/ZComputer8/task-workbench-deploy 下载源码包 task-workbench-deploy-repo2.zip，自动安装并部署，完成后打开链接。GitHub 不可用时用 https://gitee.com/ZComputer/task-workbench-deploy。**

AI 会自动完成：下载安装 skill → 建两张数据表 → 替换页面里的库 ID → 创建 web 页面并关联两张表 → 发布 → 打开发布链接 `https://workbuddy.link/p/xxxxxx`。

**用完移除**：部署成功、校验通过后，AI 会提醒你测试；回复「确认」后 WorkBuddy 自动移除临时安装的 skill。网站与数据独立保留在资料库，不受影响。

**权限**：
- 自己使用：无需任何操作；
- 给他人使用：在资料库界面把两张数据表设为「链接公开可编辑」或添加协作者（页面公开 ≠ 数据库公开）。

## 手动方式（不装 skill 也可以）

把空包 `assets/task-workbench-empty.zip` 解压，按包内 `README.md` 的"快速部署"指令发给 WorkBuddy，或按手动步骤操作。

## 仓库结构

```
├── SKILL.md                          # skill 定义（AI 读取后自动执行部署）
├── assets/task-workbench-empty.zip   # 空网站包（不含任何数据）
├── scripts/prepare_deploy.py         # 替换库 ID 脚本
├── references/deploy-guide.md        # 部署流程详解（供 AI 参考）
└── DEPLOY.md                         # 本文件
```

## 安全说明

- 空包与 skill **不含任何真实数据库 ID、账号、密码、任务数据**；
- 数据只产生在部署者自己的两张表里，互不串扰；
- 发布前请自行检查链接不要外传，权限按需设置。
