---
name: task-workbench-deploy
description: |
  一键部署「任务工作台」独立网站（组织/账户 + 独立密码登录 + 任务四视图）。
  当用户想把任务管理功能部署到自己的 WorkBuddy 资料库、需要一份不含任何数据的空网站包，
  或说“部署任务工作台/任务管理系统/给我的团队搭一个任务系统”时使用。
  本 skill 内置空包 zip 与部署脚本，自动完成建表命令、database_id 替换、页面发布指引，
  并保证空包不含任何真实库 ID、账号、密码、任务数据。
  部署成功、校验通过后，提醒用户测试；用户确认后 WorkBuddy 自动移除本 skill。
---

# Task Workbench Deploy · 任务工作台一键部署

## Overview

把「任务计划分发记录工作台」部署到任意 WorkBuddy 资料库空间：**不含任何账号与任务数据**的独立网站，
首注册使用者即主使用者（管理员），每人独立密码登录，含任务四视图（列表/看板/日历/时间线）、
组织与权限、使用者管理、逾期与完成时效、模板、全年计划等完整功能。

本 skill 自带空包，不依赖外部链接；部署者可拿空包独立搭建，不会与当前项目数据串扰。
每次部署都是全新创建（新表 + 新页面 + 新链接），重复部署也完全独立、互不覆盖。

## 内置资源

- `assets/task-workbench-empty.zip` — 空网站包
  - `index.html`：页面源码，库 ID 为占位符 `__TASK_DB_ID__` / `__ACCOUNT_DB_ID__`
  - `README.md`：给部署者看的部署指南
  - `schema/account-db.schema.json`：账户表建表结构（8 字段）
  - `schema/task-db.schema.json`：任务表建表结构（17 字段）
- `scripts/prepare_deploy.py` — 部署准备脚本（建表命令 / 替换 ID / 生成可发布 index.html）
- `references/deploy-guide.md` — 给 AI 执行者的完整操作序列与易错点

## 远程源（首次安装自动下载，部署者无需手动放置 skill）

本 skill 已发布到公开仓库。若部署者的 WorkBuddy 尚未安装本 skill，AI 收到部署请求时自动完成下载与安装：

- 主源（GitHub）：`https://github.com/ZComputer8/task-workbench-deploy/raw/main/task-workbench-deploy-repo2.zip`
- 备用源（Gitee）：`https://gitee.com/ZComputer/task-workbench-deploy/raw/main/task-workbench-deploy-repo2.zip`

AI 自动执行：curl 下载 zip → 解压 → 将 `SKILL.md`、`scripts/`、`references/`、`assets/` 放入本机 skills 目录（skill 名 `task-workbench-deploy`）→ 重新读取本文件继续执行部署。GitHub 失败自动切 Gitee。

## 部署触发句（部署者只发这一句话）

> 复制以下一句话发给 WorkBuddy：
>
> **帮我一键部署任务工作台：从 https://github.com/ZComputer8/task-workbench-deploy 下载源码包 task-workbench-deploy-repo2.zip，自动安装并部署，完成后打开链接。GitHub 不可用时用 https://gitee.com/ZComputer/task-workbench-deploy。**

AI 收到后自主完成整条链路：下载 → 安装 skill → 建表 → 替换 ID → 导入发布 → 用 `present_files` 打开发布链接。唯一手动项是权限（见 Step 5）。

## 部署流程（全自动，AI 执行；部署者只需一句话）

> AI 按下面 5 步自动完成，最终打开发布链接。token 通过 `connect_open_platform(skill_id=library)` 获取。

### Step 1 · 建两张空数据表

用资料库 skill 的 `create_database.py` 按空包 schema 建表（schema 在解压后的空包里）：

```bash
DB="<library>/database"
echo "$TOKEN" | python3 "$DB/create_database.py" --token-stdin --schema "$(cat schema/account-db.schema.json)"  # → 记下账户表 database_id
echo "$TOKEN" | python3 "$DB/create_database.py" --token-stdin --schema "$(cat schema/task-db.schema.json)"    # → 记下任务表 database_id
```

### Step 2 · 生成替换好 ID 的可发布页面

```bash
python3 "<skill_dir>/scripts/prepare_deploy.py" \
  --task-db-id <任务表ID> --account-db-id <账户表ID> --out-dir <输出目录>
```

脚本自动解压内置空包 → 替换占位符 → 校验无残留 → 输出 `index.html` + `README.md`。

### Step 3 · 导入创建 web 页面并关联两张表（关键：不再需要前端手动建页面）

用资料库 skill 的 `import_html.py`（参考 clone-flow 分支 B），导入 HTML 即创建页面节点，并写入两张表的关联：

```bash
SKILL="<library>"
DB_JSON='[{"id":"<任务表ID>"},{"id":"<账户表ID>"}]'
FNAME="任务计划分发记录工作台-$(date +%Y%m%d-%H%M).html"  # 带日期+时分，几乎不可能重名
printf '%s' "$TOKEN" | python3 "$SKILL/page/import_html.py" --token-stdin \
  "<输出目录>/index.html" --file-name "$FNAME" --databases "$DB_JSON"
# → KS_IMPORT_OK {"node_block_id":"<页面ID>", ...}
```

> 页面文件名 = 基础名 + 日期+时分，重复部署也不会同名：
> 如 `任务计划分发记录工作台-20260831-2012.html`。
> 两张表每次部署都是新建，天然独立，不会与任何一套数据串扰。

### Step 4 · 发布页面

```bash
echo "$TOKEN" | python3 "$SKILL/page/publish_page.py" --token-stdin --node-id <页面ID>
# → 返回 publishUrl：https://workbuddy.link/p/xxxxxx
```

### Step 4.5 · 打开发布链接（收尾动作，必须执行）

发布成功后用 `present_files` 打开发布链接，让部署者直接看到网站运行效果。

### Step 5 · 权限提示（唯一保留的手动项）

- 部署者**自己使用**：无需任何权限操作。
- **要给他人使用**：在资料库界面把两张数据表设为「链接公开可编辑」或添加协作者（页面公开 ≠ 数据库公开）。

### Step 6 · 部署完成，确认后移除本 skill（必须执行）

1. 校验通过（链接可打开、能注册登录、数据正常）后，用 `present_files` 打开发布链接，并提示用户：
   > **已部署成功，请测试。测试没问题请回复「确认」，我将移除临时安装的 skill。**
2. 用户回复确认后，**WorkBuddy 自动移除本 skill**：删除本机 skills 目录下的 `task-workbench-deploy` 文件夹。
3. 移除后提示：网站与数据不受影响，独立保留在资料库中；以后想再部署，把同一句话再发一次即可（会自动重新下载安装）。

> 设计目的：部署属于一次性任务，完成后移除临时 skill，避免残留在系统里干扰后续使用；
> 网站与数据永久保留，与 skill 是否安装无关。

## 质检要求（必须执行）

每次部署前先对**交付给部署者的空包**做敏感信息扫描，确认零泄露：

- 真实数据库 ID、nodeId、空间 ID、组织信息、账号、密码、token、个人发布链接 **不得出现**。
- 空包 `index.html` 必须只含 `__TASK_DB_ID__` / `__ACCOUNT_DB_ID__` 占位符。

扫描命令参考（在空包目录执行）：

```bash
grep -rn "真实库ID\|账号\|密码\|token前缀\|workbuddy.link/p/实际链接" <空包目录>
```

## 易错点

- 占位符替换不干净 → 页面空白：务必 `grep "__"` 复查。
- 两张表缺一不可：账户表缺 → 无法注册；任务表缺 → 页面空白。
- `import_html` 的 `--databases` 参数顺序/内容必须与两张新表一致，否则页面读不到数据。
- 发布用 `publish_page`；若只要草稿态则不发布（克隆流程默认不发布）。
- 建表 schema 的 select 字段用 `config:{"select":{...}}`（create_database 的字段格式要求）。
